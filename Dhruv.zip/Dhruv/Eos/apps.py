from django.apps import AppConfig


class EosConfig(AppConfig):
    name = 'Eos'
