from django.db.models import query
from . models import Product,Contact
from django.contrib import messages
from django.http.response import HttpResponse
from django.shortcuts import redirect, render

from django.contrib.auth.models import User,auth 
# Create your views here.

def index(request):
    products = Product.objects.all()
    params = {'product':products}
    return render(request,'index.html',params)

def About(request):
    return render(request,'about.html')

def sell(request):
    if request.method=="POST":
        product_name  = request.POST.get('product_name','')
        product_price = request.POST.get('product_price','')
        product_brand = request.POST.get('product_brand','')
        desc = request.POST.get('desc','')
        publish_date = request.POST.get('publish_date','')
        product_category = request.POST.get('product_category','')
        owner_name = request.POST.get('owner_name','')
        owner_gmail = request.POST.get('owner_gmail','')
        owner_phone = request.POST.get('owner_phone','')
        owner_address = request.POST.get('owner_address','')

        data = Product(product_name=product_name, product_price= product_price,product_brand= product_brand,desc= desc,
        publish_date=publish_date,product_category=product_category,owner_name=owner_name,owner_gmail=owner_gmail,
        owner_phone=owner_phone, owner_address= owner_address)
        data.save()

    return render(request,'sell.html')

def contact(request):
    if request.method=="POST":
        name  = request.POST.get('name','')
        email = request.POST.get('email','')
        phone = request.POST.get('phone','')
        query = request.POST.get('query','')
        feedback = request.POST.get('feedback','')
        data = Contact(name= name, email= email, phone= phone, query= query, feedback= feedback)
        data.save()

    return render(request,'contact.html')

def Search(request):

    query = request.GET.get('search')

    product = Product.objects.filter(product_name__icontains=query)

    params = {'product':product}

    return render(request,'index.html',params)
    
def ProductView(request,proid):
    product = Product.objects.filter(id=proid)
    return render(request,'productview.html',{'product' : product[0]})
    

def Checkout(request):
    return render(request,'checkout.html')


def register(request):
    if request.method == 'POST':
        first_name =request.POST['first_name']
        last_name  =request.POST['last_name']
        email      =request.POST['email']
        password1  =request.POST['password1']
        password2  =request.POST['password2']
        username   =request.POST['username']

        if password1==password2:
            if User.objects.filter(username=username).exists():
                messages.info(request,'username taken')
                return redirect('/register/')
            elif User.objects.filter(email=email).exists():
                messages.info(request,'email Taken')
                return redirect('/register/')
            else:
                user = User.objects.create_user(username=username,password=password1,email=email,first_name=first_name,last_name=last_name)
                user.save();
                return redirect('/login/')
        else:
            messages.info(request,'password not matching!!!!')
            return redirect('/register/')
        return redirect("/")

    else:
        return render(request,'register.html')

def login(request):
    if request.method== 'POST':
        username = request.POST['username']
        password = request.POST['password']

        user = auth.authenticate(username=username,password=password)

        if user is not None:
            auth.login(request,user)
            return redirect("/")
        else:
            messages.info(request,'invalid credential!!')
            return redirect('login')
    else:
        return render(request,'login.html')

def logout(request):
    auth.logout(request)
    return redirect('/')