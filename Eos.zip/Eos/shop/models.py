from django.db import models
from django.db.models import query

# Create your models here.

class Product(models.Model):
    product_name = models.CharField(max_length=50)
    product_price = models.IntegerField()
    product_brand = models.CharField(max_length=50)
    desc = models.CharField(max_length=100)
    publish_date = models.DateField()
    product_category = models.CharField(max_length=50)

    product_img = models.ImageField(upload_to="images/")

    owner_name = models.CharField(max_length=50)
    owner_gmail = models.EmailField()
    owner_phone = models.SmallIntegerField()
    owner_address = models.CharField(max_length=200)

    def __str__(self):
        return self.product_name

class Contact(models.Model):
    name = models.CharField(max_length=50,)
    email = models.CharField(max_length=70,default="")
    phone = models.CharField(max_length=10,default="")
    query = models.CharField(max_length=200,default="")
    feedback = models.CharField(max_length=200,default="")
    def __str__(self):
        return self.feedback