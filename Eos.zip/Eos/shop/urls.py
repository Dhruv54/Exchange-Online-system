from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
    path("",views.index, name="ShopHome"),
    path("register/",views.register,name="Register"),
    path("login/",views.login,name="Login"),
    path("logout/",views.logout,name="logout"),
    path("about/",views.About, name="AboutUs"),
    path("contact/",views.contact, name="ContactUs"),
    path("search/",views.Search, name="Search"),
    path("products/<int:proid>",views.ProductView, name="ProductView"),
    path("checkout/",views.Checkout, name="Checkout"),
    path("sell/",views.sell, name="Sell"),
]