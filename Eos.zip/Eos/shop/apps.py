from django.apps import AppConfig


class ShopConfig(AppConfig):
    name = 'shop'
