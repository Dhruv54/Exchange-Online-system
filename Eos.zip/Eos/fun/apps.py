from django.apps import AppConfig


class FunConfig(AppConfig):
    name = 'fun'
